import React, { useState, useEffect } from 'react';

const LeadsPage = ({ token }) => {
    const [leads, setLeads] = useState([]);
    const [newLead, setNewLead] = useState({ name: '', email: '', phone: '', address: '' });

    const fetchLeads = async () => {
        const response = await fetch('http://localhost:5000/leads', {
            headers: { Authorization: `Bearer ${token}` }
        });
        const data = await response.json();
        setLeads(data);
    };

    const addLead = async () => {
        await fetch('http://localhost:5000/leads', {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newLead)
        });
        fetchLeads();
    };

    useEffect(() => {
        fetchLeads();
    }, []);

    return (
        <div>
            <h1>Leads</h1>
            <input
                type="text"
                placeholder="Name"
                value={newLead.name}
                onChange={e => setNewLead({ ...newLead, name: e.target.value })}
            />
            <input
                type="text"
                placeholder="Email"
                value={newLead.email}
                onChange={e => setNewLead({ ...newLead, email: e.target.value })}
            />
            <input
                type="text"
                placeholder="Phone"
                value={newLead.phone}
                onChange={e => setNewLead({ ...newLead, phone: e.target.value })}
            />
            <input
                type="text"
                placeholder="Address"
                value={newLead.address}
                onChange={e => setNewLead({ ...newLead, address: e.target.value })}
            />
            <button onClick={addLead}>Add Lead</button>
            <ul>
                {leads.map(lead => (
                    <li key={lead.id}>
                        {lead.name} - {lead.address} <button>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default LeadsPage;