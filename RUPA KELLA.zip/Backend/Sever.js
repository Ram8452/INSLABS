const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());


const users = [
    { id: 1, username: 'admin', role: 'admin', password: 'admin123' },
    { id: 2, username: 'telecaller', role: 'telecaller', password: 'tele123' }
];

const leads = [];
const SECRET_KEY = 'mysecretkey';


app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        const token = jwt.sign({ id: user.id, role: user.role }, SECRET_KEY, { expiresIn: '1h' });
        return res.json({ token });
    }
    return res.status(401).json({ message: 'Invalid credentials' });
});


const authenticate = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(403).send('Access denied');
    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        req.user = decoded;
        next();
    } catch {
        return res.status(403).send('Invalid token');
    }
};


app.get('/leads', authenticate, (req, res) => {
    return res.json(leads);
});

app.post('/leads', authenticate, (req, res) => {
    leads.push({ id: leads.length + 1, ...req.body });
    return res.send('Lead added');
});

app.put('/leads/:id', authenticate, (req, res) => {
    const lead = leads.find(lead => lead.id === parseInt(req.params.id));
    if (lead) {
        lead.address = req.body.address;
        return res.send('Lead updated');
    }
    return res.status(404).send('Lead not found');
});

app.delete('/leads/:id', authenticate, (req, res) => {
    const index = leads.findIndex(lead => lead.id === parseInt(req.params.id));
    if (index !== -1) {
        leads.splice(index, 1);
        return res.send('Lead deleted');
    }
    return res.status(404).send('Lead not found');
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));